/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "ti_msp_dl_config.h"
//#include "oled.h"
#include "stdio.h"
#include "string.h"
#include "board.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"

int32_t Speed_left,Speed_right;
uint16_t pwm_left=0,pwm_right=0,pwm_yaw=0;   //PWM�Ƚ�ֵ

uint8_t status;

float Err_r=0,LastErr_r=0,LastLastErr_r=0;
float pwm_CCR_r=0,Add_CCR_r=0;						//pwm�µ�PWM�Ƚ�ֵ��add���µ�PWMռ�ձȸ���ֵ
float Err_l=0,LastErr_l=0,LastLastErr_l=0;
float pwm_CCR_l=0,Add_CCR_l=0;						//pwm�µ�PWM�Ƚ�ֵ��add���µ�PWMռ�ձȸ���ֵ
float p=1.0,i=0.5,d=0.5;                       //����ϵ��������ϵ����΢��ϵ��

float Err_yaw=0,LastErr_yaw=0,LastLastErr_yaw=0;
float pwm_CCR_yaw=0,Add_CCR_yaw=0;						//pwm�µ�PWM�Ƚ�ֵ��add���µ�PWMռ�ձȸ���ֵ
float p_yaw=7.0,i_yaw=0.5,d_yaw=0.5;                       //����ϵ��������ϵ����΢��ϵ��
int32_t setspeed_l=120,setspeed_r=100,base_pwm=550;                             //�趨Ŀ���ٶ�
float set_yaw=0.0;

int16_t rxbuf = 0, cx = 160,cy=160;
int flag_num=0,fh1=1,fh2=1,a=0;

char str1[30];
char str2[30];
char str3[30];
char str4[30];

volatile int32_t count_left=0;
volatile int32_t count_right=0;

uint8_t ret = 1;
float pitch=0,roll=0,yaw=0;
uint8_t overflowFlag;

volatile bool gCheckADC;
volatile uint16_t gAdcResult;

volatile uint16_t gAdcResult0;
volatile uint16_t gAdcResult1;
volatile uint16_t gAdcResult2;
int flag0,flag1,flag2,flag3,flag4,flag5,flag6,flag7,flag8;
int num,last_num=1,count=0,stop_flag=0;
int aflag=0,b=0,c=0,e=0,mode=0,zuse=0,zuse1=0,f=0,f0=0,f1=0,f2=0,f3=0,f4=0,f5=0,f6=0,f7=0,f8=0,f9=0,f11=0;
void Delay_ms(int num)
{
    delay_cycles(num*32000);
}
void Delay_us(int num)
{
    delay_cycles(num*32);
}

int16_t myabs(int a)
{
	int temp;
	if(a<0) 
		temp=-a;
	else 
		temp=a;
	return temp;
}

void stop(void)
{
	DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);        //��ת
    DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
	DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);       //��ת
    DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
}
void set_dir(void)
{
    if(setspeed_l<0)
    {
        DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);
    }
    else if(setspeed_l>0)
    {
        DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
    }
    else
    {
        DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);        //��ת
        DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
    }
    if(setspeed_r>0)
    {
        DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
    }
    else if(setspeed_r<0)
    {
        DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);
    }
    else
    {
        DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);       //��ת
        DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
    }
}
float PID_r(int16_t speed)
{
    Err_r=myabs(setspeed_r)-myabs(speed);                            				//�趨�ٶ�-ʵʱ�ٶ�
    Add_CCR_r = p*(Err_r-LastErr_r)+i*(Err_r)+d*(Err_r+LastLastErr_r-2*LastErr_r);	//PWMռ�ձ����ӵĲ���=��������+���ֻ���+΢�ֻ���
	if(Add_CCR_r<-1||Add_CCR_r>1)                                           //΢С�仯�����ģ����ٶ���
		pwm_CCR_r+=Add_CCR_r; 
    // pwm_CCR=myabs(pwm_CCR)+590;                      	
	if(pwm_CCR_r>999)														//�޷�
        pwm_CCR_r=999;
    if(pwm_CCR_r<0)
        pwm_CCR_r=0;
    LastLastErr_r=LastErr_r;                       							//����һ����ֵ�����ϴ����
    LastErr_r=Err_r;														//��������ֵ���ϴ����
    return pwm_CCR_r;														//����PWM�µ�ռ�ձ�ֵ
}

float PID_l(int16_t speed)
{
	
    Err_l=myabs(setspeed_l)-myabs(speed);                            				//�趨�ٶ�-ʵʱ�ٶ�
    Add_CCR_l = p*(Err_l-LastErr_l)+i*(Err_l)+d*(Err_l+LastLastErr_l-2*LastErr_l);	//PWMռ�ձ����ӵĲ���=��������+���ֻ���+΢�ֻ���
	if(Add_CCR_l<-1||Add_CCR_l>1)                                           //΢С�仯�����ģ����ٶ���
		pwm_CCR_l+=Add_CCR_l; 
    // pwm_CCR=myabs(pwm_CCR)+590;                      	
	if(pwm_CCR_l>999)														//�޷�
        pwm_CCR_l=999;
    if(pwm_CCR_l<0)
        pwm_CCR_l=0;
    LastLastErr_l=LastErr_l;                       							//����һ����ֵ�����ϴ����
    LastErr_l=Err_l;														//��������ֵ���ϴ����
    return pwm_CCR_l;														//����PWM�µ�ռ�ձ�ֵ
}
void xj_dl()
{
	int low_speed=900,high_speed=680;
	if(flag0||flag1||flag2||flag3||flag4||flag5||flag6||flag7||flag8)
	{
		if(flag0||flag1||flag2||flag7)
		{
			if(!(flag4||flag5||flag6||flag8))
			{
				if(flag0||flag7)
				{
					DL_TimerG_setCaptureCompareValue(PWM_0_INST,low_speed+50, DL_TIMER_CC_0_INDEX);
					DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed-200, DL_TIMER_CC_1_INDEX);
				}
				else
				{
					DL_TimerG_setCaptureCompareValue(PWM_0_INST,low_speed, DL_TIMER_CC_0_INDEX);
					DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed, DL_TIMER_CC_1_INDEX);
				}
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed-30, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed, DL_TIMER_CC_1_INDEX);
			}
		}
		else if(flag4||flag5||flag6||flag8)
		{
			if(flag6||flag8)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed-200, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,low_speed+50, DL_TIMER_CC_1_INDEX);
			}
			else
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,low_speed, DL_TIMER_CC_1_INDEX);
			}
		}
		else
		{
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed-30, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed, DL_TIMER_CC_1_INDEX);
		}
		
	}
	else
	{
		DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed-30, DL_TIMER_CC_0_INDEX);
		DL_TimerG_setCaptureCompareValue(PWM_0_INST,high_speed, DL_TIMER_CC_1_INDEX);
	}
}
//void xj_adc(void)
//{
//	int err_adc;
//	err_adc=gAdcResult-0x7ff;
//	if(err_adc>499)														//�޷�
//        err_adc=499;
//    if(err_adc<-499)
//        err_adc=-499;
//	DL_TimerG_setCaptureCompareValue(PWM_0_INST,500-err_adc, DL_TIMER_CC_0_INDEX);
//	DL_TimerG_setCaptureCompareValue(PWM_0_INST,500+err_adc, DL_TIMER_CC_1_INDEX);
//}
//float PID_yaw(int16_t set_yaw,int16_t yaw)//set_yaw=0,180,-103,77
//{                           			
//    // Err_yaw=set_yaw-yaw;                            				//�趨�ٶ�-ʵʱ�ٶ�
//    // Add_CCR_yaw = p_yaw*(Err_yaw-LastErr_yaw)+i_yaw*(Err_yaw)+d_yaw*(Err_yaw+LastLastErr_yaw-2*LastErr_yaw);	//PWMռ�ձ����ӵĲ���=��������+���ֻ���+΢�ֻ���
//	// if(Add_CCR_yaw<-1||Add_CCR_yaw>1)                                           //΢С�仯�����ģ����ٶ���
//	// 	pwm_CCR_yaw+=Add_CCR_yaw; 
//    // // pwm_CCR=myabs(pwm_CCR)+590;                      	
//	
//    // LastLastErr_yaw=LastErr_yaw;                       							//����һ����ֵ�����ϴ����
//    // LastErr_yaw=Err_yaw;														//��������ֵ���ϴ����
//    // return pwm_CCR_yaw;

//	if(set_yaw>90||set_yaw<-90)
//	{
////		yaw=
//	}
//    pwm_CCR_yaw=p_yaw*(set_yaw-yaw);
//    if(pwm_CCR_yaw>449)														//�޷�
//        pwm_CCR_yaw=499;
//    if(pwm_CCR_yaw<-449)
//        pwm_CCR_yaw=-449;
//    // if(set_yaw>yaw)
//    //     pwm_CCR_yaw=200;
//    // else
//    //     pwm_CCR_yaw=-200;
//    return pwm_CCR_yaw;
//}
void YAW(void)
{
    if(yaw>=0)
    {
        if(set_yaw>=0)
        {
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm+pwm_yaw, DL_TIMER_CC_0_INDEX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm-pwm_yaw, DL_TIMER_CC_1_INDEX);
        }
        else 
        {
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm-50, DL_TIMER_CC_0_INDEX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm+50, DL_TIMER_CC_1_INDEX);
        }
    }
    else 
    {
        if(set_yaw<=0)
        {
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm-pwm_yaw, DL_TIMER_CC_1_INDEX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm+pwm_yaw, DL_TIMER_CC_0_INDEX);
        }
        else 
        {
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm+50, DL_TIMER_CC_0_INDEX);
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,base_pwm-50, DL_TIMER_CC_1_INDEX);
        }
    }
}
void readpin(void)
{
	if(DL_GPIO_readPins(GPIOA,GPIO_xj_PIN_3_PIN))
		flag0=1;
	else
		flag0=0;
	if(DL_GPIO_readPins(GPIOA,GPIO_xj_PIN_4_PIN))
		flag1=1;
	else
		flag1=0;
	if(DL_GPIO_readPins(GPIOA,GPIO_xj_PIN_5_PIN))
		flag2=1;
	else
		flag2=0;
	if(DL_GPIO_readPins(GPIOA,GPIO_xj_PIN_6_PIN))
		flag3=1;
	else
		flag3=0;
	if(DL_GPIO_readPins(GPIOA,GPIO_xj_PIN_7_PIN))
		flag4=1;
	else
		flag4=0;
	if(DL_GPIO_readPins(GPIOB,GPIO_xj_PIN_9_PIN))
		flag5=1;
	else
		flag5=0;
	if(DL_GPIO_readPins(GPIOB,GPIO_xj_PIN_10_PIN))
		flag6=1;
	else
		flag6=0;
	if(DL_GPIO_readPins(GPIOB,GPIO_xj_PIN_11_PIN))
		flag7=1;
	else
		flag7=0;
	if(DL_GPIO_readPins(GPIOB,GPIO_xj_PIN_12_PIN))
		flag8=1;
	else
		flag8=0;
}
void sg(void)
{
	DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
	DL_GPIO_setPins(GPIO_buz_PORT,GPIO_buz_PIN_8_PIN);
	Delay_ms(20);
	DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
	DL_GPIO_clearPins(GPIO_buz_PORT,GPIO_buz_PIN_8_PIN);
}
void mode1(void)
{
	if(!c)
	{
		Delay_ms(1000);
		c=1;
	}
	if(!stop_flag)
	{
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
		if(zuse>30)
			readpin();
		if(flag0||flag1||flag2||flag3||flag4||flag5||flag6)
			num=0;
		else
		{
//			pwm_yaw=PID_yaw(0,(int)yaw);
//			YAW();
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,550, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,550, DL_TIMER_CC_1_INDEX);
			num=1;
		}
		if(last_num!=num)
		{
			sg();
			count++;
		}
		if(count==1)
		{
			stop_flag=1;
			stop();
		}
		last_num=num;
//		DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
		Delay_ms(20);
		zuse++;
	}else
		stop();
}
void mode2(void)
{
	if(!c)
	{
		Delay_ms(1000);
		c=1;
	}
	if(!stop_flag)
	{
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
		if(zuse>58)
		{
			readpin();
			readpin();
//			if(!e)
//			{
//				sg();
//				e=1;
//			}
		}
//		if(count==2)
//		{
//			if(zuse1>25)//�߰��ߵ�ʱ��
//			{
//				readpin();
//	//			if(!e)
//	//			{
//	//				sg();
//	//				e=1;
//	//			}
//			}
//		}
		if(flag0||flag1||flag2||flag3||flag4||flag5||flag6)
		{
			xj_dl();
			num=0;
		}
		else
		{
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_1_INDEX);
//			if (count==0)
//			{
//				pwm_yaw=PID_yaw(0,(int)yaw);
//				YAW();	
//			}
//			else if(count==2)
//			{
//				pwm_yaw=PID_yaw(180,(int)yaw);
//				YAW();
//				aflag=1;
//			}
			num=1;
		}
		if(last_num!=num)
		{
			sg();
			count++;
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
			Delay_ms(200);
		}
		if(count==2)
		{
			if(!b)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,480, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,570, DL_TIMER_CC_1_INDEX);
				Delay_ms(1500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
//				Delay_ms(800);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
//				Delay_ms(200);
				b=1;
			}
		}
		if(count==3)
		{
			if(!e)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(50);
				e=1;
			}
		}
		if(count==4)
		{
			stop_flag=1;
			stop();
//			DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_0_PIN);
		}
		last_num=num;
		zuse++;
//		zuse1++;
//		DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
//		Delay_ms(20);
		}
	else
		stop();
}

void mode3(void)
{
	if(!c)
	{
		Delay_ms(1000);
		c=1;
	}
	if(!stop_flag)
	{
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);      	 //
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
//		if(zuse>79)
//		{
			readpin();
			readpin();
//			if(!e)
//			{
//				sg();
//				e=1;
//			}
//			if(count==2)
//				zuse=0;
//		}
		if(flag0||flag1||flag2||flag3||flag4||flag5||flag6)
		{
			xj_dl();
			num=0;
		}
		else
		{
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_1_INDEX);
//			if(aflag)
//			{
//	//			pwm_yaw=PID_yaw(0,(int)yaw);
//	//			YAW();
//				aflag=0;
//			}
//			else{
////				pwm_yaw=PID_yaw(-103,(int)yaw);
//	//			YAW();
//				aflag=1;
//			}
			num=1;
		}
		if(last_num!=num)
		{
			sg();
			count++;
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
			Delay_ms(100);
		}
		if(count==1)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!b)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
//				Delay_ms(475);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				b=1;
			}
		}
		if(count==2)
		{
			if(!aflag)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_1_INDEX);
				Delay_ms(1250);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
				Delay_ms(630);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_1_INDEX);
//				Delay_ms(700);
				aflag=1;
			}
		}
		if(count==3)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!c)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				c=1;
			}
		}
		if(count==4)
		{
			stop_flag=1;
			stop();
		}
		last_num=num;
		zuse++;
		zuse1++;
//		DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
//		Delay_ms(20);
	}else
		stop();
}

void mode4(void)
{
	if(!c)
	{
		Delay_ms(1000);
		c=1;
	}
	if(!stop_flag)
	{
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left1_PIN);      	 //
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_left2_PIN);
		DL_GPIO_setPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right1_PIN);      	 //��ת
		DL_GPIO_clearPins(GPIO_Motor_PORT,GPIO_Motor_PIN_right2_PIN);
		if(zuse>79)
		{
			readpin();
			readpin();
//			if(!e)
//			{
//				sg();
//				e=1;
//			}
//			if(count==2)
//				zuse=0;
		}
		if(flag0||flag1||flag2||flag3||flag4||flag5||flag6)
		{
			xj_dl();
			num=0;
		}
		else
		{
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,720, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,720, DL_TIMER_CC_1_INDEX);
//			if(aflag)
//			{
//	//			pwm_yaw=PID_yaw(0,(int)yaw);
//	//			YAW();
//				aflag=0;
//			}
//			else{
////				pwm_yaw=PID_yaw(-103,(int)yaw);
//	//			YAW();
//				aflag=1;
//			}
			num=1;
		}
		if(last_num!=num)
		{
			sg();
			count++;
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
			DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
			Delay_ms(100);
		}
		if(count==1)
		{
			if(!b)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				b=1;
			}
		}
		if(count==2)
		{
			if(!f)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_1_INDEX);
				Delay_ms(1250);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
				Delay_ms(630);
				f=1;
			}
		}
		if(count==3)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!c)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				c=1;
			}
		}
		if(count==4)
		{
			if(!aflag)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_1_INDEX);
				Delay_ms(1600);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				aflag=1;
			}
		}
		if(count==5)
		{
			if(!f1)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f1=1;
			}
		}
		if(count==6)
		{
			if(!f2)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_1_INDEX);
				Delay_ms(1250);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
				Delay_ms(630);
				f2=1;
			}
		}
		if(count==7)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!f3)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f3=1;
			}
		}
		if(count==8)
		{
			if(!f4)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_1_INDEX);
				Delay_ms(1500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				f4=1;
			}
		}
		if(count==9)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!f5)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f5=1;
			}
		}
		if(count==10)
		{
			if(!f6)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_1_INDEX);
				Delay_ms(1250);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
				Delay_ms(630);
				f6=1;
			}
		}
		if(count==11)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!f7)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f7=1;
			}
		}
		if(count==12)
		{
			if(!f8)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_1_INDEX);
				Delay_ms(1500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				f8=1;
			}
		}
		if(count==13)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!f9)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f9=1;
			}
		}
		if(count==14)
		{
			if(!f0)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(100);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,700, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,500, DL_TIMER_CC_1_INDEX);
				Delay_ms(1250);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,740, DL_TIMER_CC_1_INDEX);
//				Delay_ms(250);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,900, DL_TIMER_CC_1_INDEX);
				Delay_ms(630);
				f0=1;
			}
		}
		if(count==15)//��Բ���ڲ����Ѳ��ʱ����С����������
		{
			if(!f11)
			{
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,999, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,650, DL_TIMER_CC_0_INDEX);
				DL_TimerG_setCaptureCompareValue(PWM_0_INST,850, DL_TIMER_CC_1_INDEX);
				Delay_ms(500);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_0_INDEX);
//				DL_TimerG_setCaptureCompareValue(PWM_0_INST,600, DL_TIMER_CC_1_INDEX);
				f11=1;
			}
		}
		if(count==16)
		{
			stop_flag=1;
			stop();
		}
		last_num=num;
		zuse++;
		zuse1++;
//		DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
//		Delay_ms(20);
	}else
		stop();
}
//void SendString(char *str)//���Է�װ���sendstring,ʹ��ǰҪ��UART
//{
//    while(*str != '\0')
//    {
//        DL_UART_Main_transmitDataBlocking(UART_0_INST, *str++);
//    }
//}
int main(void)
{
    uint8_t ret = 1;
    float pitch=0,roll=0,yaw=0;
	int c=0;
    SYSCFG_DL_init();
	DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
    while(DL_GPIO_readPins(GPIO_BUTTON_PORT,GPIO_BUTTON_PIN_BUTTON1_PIN));
	Delay_ms(1000);
	
	DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
//	Delay_ms(1000);
//	board_init();
//	MPU6050_Init();
//    while( mpu_dmp_init() )
//		Delay_ms(200);

//    NVIC_EnableIRQ(GPIO_BUTTON_INT_IRQN);
//    NVIC_EnableIRQ(GPIO_Encoder_INT_IRQN);
//    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);
//    DL_TimerA_startCounter(TIMER_0_INST);
    DL_TimerG_startCounter(PWM_0_INST);
//	NVIC_EnableIRQ(ADC12_0_INST_INT_IRQN);
//    gCheckADC = false;
//	NVIC_EnableIRQ(UART_0_INST_INT_IRQN);
//	DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_1_PIN);





    while (1)
	{	
//		set_dir();
		if(!DL_GPIO_readPins(GPIO_BUTTON_PORT,GPIO_BUTTON_PIN_BUTTON1_PIN))
			mode=1;
		else if(!DL_GPIO_readPins(GPIO_BUTTON_PORT,GPIO_BUTTON_PIN_BUTTON2_PIN))
			mode=2;
		else if(!DL_GPIO_readPins(GPIO_BUTTON_PORT,GPIO_BUTTON_PIN_BUTTON3_PIN))
			mode=3;
		else if(!DL_GPIO_readPins(GPIO_BUTTON_PORT,GPIO_BUTTON_PIN_BUTTON4_PIN))
			mode=4;
		
		Delay_ms(20);
		
//		if(mode==0)
//			stop();
		if (mode==1)
//			DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
			mode1();
		else if(mode==2)
//			DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
			mode2();
		else if(mode==3)
//			DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
			mode3();
		else if(mode==4)
//			DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
			mode4();
	}
}

void TIMER_0_INST_IRQHandler(void)
{
    switch (DL_TimerA_getPendingInterrupt(TIMER_0_INST)) 
    {
        case DL_TIMER_IIDX_ZERO:
            // setspeed_l=cx;
            // setspeed_r=cy;
//			int speed_l=100+setspeed_l*2;
            Speed_left=count_left*100*60/265;
            count_left=0;
            pwm_left=PID_l(Speed_left);                               //���µıȽ�ֵ��ֵ��CCR     
            DL_TimerG_setCaptureCompareValue(PWM_0_INST,1000-pwm_left, DL_TIMER_CC_0_INDEX);
			int speed_r=100+setspeed_r*2;
//            Speed_right=count_right*100*60/265;
//            count_right=0;
//            pwm_right=PID_r(Speed_right);                               //���µıȽ�ֵ��ֵ��CCR     
            DL_TimerG_setCaptureCompareValue(PWM_0_INST, 1000-speed_r, DL_TIMER_CC_1_INDEX);	
            break;
        default:
            break;
    }
}

void GROUP1_IRQHandler(void)
{
    uint32_t gpio_left=DL_GPIO_getEnabledInterruptStatus(GPIOA,GPIO_Encoder_PIN_left_A_PIN);
    if(gpio_left & GPIO_Encoder_PIN_left_A_PIN)
    {
		
        if(DL_GPIO_readPins(GPIOA,GPIO_Encoder_PIN_left_B_PIN)){
			DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
            count_left--;}
        else{
		DL_GPIO_clearPins(GPIO_test_PORT,GPIO_test_PIN_2_PIN);
            count_left++;}
        DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Encoder_PIN_left_A_PIN);
    }
    uint32_t gpio_right=DL_GPIO_getEnabledInterruptStatus(GPIOA,GPIO_Encoder_PIN_right_A_PIN);
    if(gpio_right & GPIO_Encoder_PIN_right_A_PIN)
    {
		
        if(DL_GPIO_readPins(GPIOA,GPIO_Encoder_PIN_right_B_PIN))
            count_right--;
        else
            count_right++;
        DL_GPIO_clearInterruptStatus(GPIOA,GPIO_Encoder_PIN_right_A_PIN);
    }
}


//void ADC12_0_INST_IRQHandler(void)
//{
//    switch (DL_ADC12_getPendingInterrupt(ADC12_0_INST)) {
//        case DL_ADC12_IIDX_MEM0_RESULT_LOADED:
//			DL_GPIO_setPins(GPIO_test_PORT,GPIO_test_PIN_0_PIN);
//            gCheckADC = true;
//            break;
//        default:
//            break;
//    }
//}
