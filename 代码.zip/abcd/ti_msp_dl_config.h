/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_0 */
#define PWM_0_INST                                                         TIMG0
#define PWM_0_INST_IRQHandler                                   TIMG0_IRQHandler
#define PWM_0_INST_INT_IRQN                                     (TIMG0_INT_IRQn)
#define PWM_0_INST_CLK_FREQ                                             32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_0_C0_PORT                                                 GPIOA
#define GPIO_PWM_0_C0_PIN                                         DL_GPIO_PIN_12
#define GPIO_PWM_0_C0_IOMUX                                      (IOMUX_PINCM34)
#define GPIO_PWM_0_C0_IOMUX_FUNC                     IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_0_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_0_C1_PORT                                                 GPIOA
#define GPIO_PWM_0_C1_PIN                                         DL_GPIO_PIN_13
#define GPIO_PWM_0_C1_IOMUX                                      (IOMUX_PINCM35)
#define GPIO_PWM_0_C1_IOMUX_FUNC                     IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_PWM_0_C1_IDX                                    DL_TIMER_CC_1_INDEX



/* Defines for TIMER_0 */
#define TIMER_0_INST                                                     (TIMA0)
#define TIMER_0_INST_IRQHandler                                 TIMA0_IRQHandler
#define TIMER_0_INST_INT_IRQN                                   (TIMA0_INT_IRQn)
#define TIMER_0_INST_LOAD_VALUE                                          (1249U)



/* Defines for UART_0 */
#define UART_0_INST                                                        UART2
#define UART_0_INST_IRQHandler                                  UART2_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOB
#define GPIO_UART_0_TX_PORT                                                GPIOB
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_16
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_17
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM33)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM43)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM33_PF_UART2_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM43_PF_UART2_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_32_MHZ_115200_BAUD                                      (17)
#define UART_0_FBRD_32_MHZ_115200_BAUD                                      (23)





/* Port definition for Pin Group GPIO_test */
#define GPIO_test_PORT                                                   (GPIOB)

/* Defines for PIN_2: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_test_PIN_2_PIN                                     (DL_GPIO_PIN_20)
#define GPIO_test_PIN_2_IOMUX                                    (IOMUX_PINCM48)
/* Port definition for Pin Group GPIO_buz */
#define GPIO_buz_PORT                                                    (GPIOA)

/* Defines for PIN_8: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_buz_PIN_8_PIN                                      (DL_GPIO_PIN_27)
#define GPIO_buz_PIN_8_IOMUX                                     (IOMUX_PINCM60)
/* Port definition for Pin Group GPIO_Motor */
#define GPIO_Motor_PORT                                                  (GPIOA)

/* Defines for PIN_left1: GPIOA.2 with pinCMx 7 on package pin 42 */
#define GPIO_Motor_PIN_left1_PIN                                 (DL_GPIO_PIN_2)
#define GPIO_Motor_PIN_left1_IOMUX                                (IOMUX_PINCM7)
/* Defines for PIN_left2: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_Motor_PIN_left2_PIN                                 (DL_GPIO_PIN_7)
#define GPIO_Motor_PIN_left2_IOMUX                               (IOMUX_PINCM14)
/* Defines for PIN_right1: GPIOA.8 with pinCMx 19 on package pin 54 */
#define GPIO_Motor_PIN_right1_PIN                                (DL_GPIO_PIN_8)
#define GPIO_Motor_PIN_right1_IOMUX                              (IOMUX_PINCM19)
/* Defines for PIN_right2: GPIOA.9 with pinCMx 20 on package pin 55 */
#define GPIO_Motor_PIN_right2_PIN                                (DL_GPIO_PIN_9)
#define GPIO_Motor_PIN_right2_IOMUX                              (IOMUX_PINCM20)
/* Port definition for Pin Group GPIO_Encoder */
#define GPIO_Encoder_PORT                                                (GPIOA)

/* Defines for PIN_left_A: GPIOA.10 with pinCMx 21 on package pin 56 */
// pins affected by this interrupt request:["PIN_left_A","PIN_right_A"]
#define GPIO_Encoder_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_Encoder_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_Encoder_PIN_left_A_IIDX                        (DL_GPIO_IIDX_DIO10)
#define GPIO_Encoder_PIN_left_A_PIN                             (DL_GPIO_PIN_10)
#define GPIO_Encoder_PIN_left_A_IOMUX                            (IOMUX_PINCM21)
/* Defines for PIN_left_B: GPIOA.11 with pinCMx 22 on package pin 57 */
#define GPIO_Encoder_PIN_left_B_PIN                             (DL_GPIO_PIN_11)
#define GPIO_Encoder_PIN_left_B_IOMUX                            (IOMUX_PINCM22)
/* Defines for PIN_right_A: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_Encoder_PIN_right_A_IIDX                       (DL_GPIO_IIDX_DIO14)
#define GPIO_Encoder_PIN_right_A_PIN                            (DL_GPIO_PIN_14)
#define GPIO_Encoder_PIN_right_A_IOMUX                           (IOMUX_PINCM36)
/* Defines for PIN_right_B: GPIOA.16 with pinCMx 38 on package pin 9 */
#define GPIO_Encoder_PIN_right_B_PIN                            (DL_GPIO_PIN_16)
#define GPIO_Encoder_PIN_right_B_IOMUX                           (IOMUX_PINCM38)
/* Port definition for Pin Group GPIO_OLED */
#define GPIO_OLED_PORT                                                   (GPIOA)

/* Defines for PIN_SCL: GPIOA.26 with pinCMx 59 on package pin 30 */
#define GPIO_OLED_PIN_SCL_PIN                                   (DL_GPIO_PIN_26)
#define GPIO_OLED_PIN_SCL_IOMUX                                  (IOMUX_PINCM59)
/* Defines for PIN_SDA: GPIOA.6 with pinCMx 11 on package pin 46 */
#define GPIO_OLED_PIN_SDA_PIN                                    (DL_GPIO_PIN_6)
#define GPIO_OLED_PIN_SDA_IOMUX                                  (IOMUX_PINCM11)
/* Port definition for Pin Group GPIO_BUTTON */
#define GPIO_BUTTON_PORT                                                 (GPIOB)

/* Defines for PIN_BUTTON1: GPIOB.8 with pinCMx 25 on package pin 60 */
// pins affected by this interrupt request:["PIN_BUTTON1","PIN_BUTTON2","PIN_BUTTON3","PIN_BUTTON4"]
#define GPIO_BUTTON_INT_IRQN                                    (GPIOB_INT_IRQn)
#define GPIO_BUTTON_INT_IIDX                    (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_BUTTON_PIN_BUTTON1_IIDX                         (DL_GPIO_IIDX_DIO8)
#define GPIO_BUTTON_PIN_BUTTON1_PIN                              (DL_GPIO_PIN_8)
#define GPIO_BUTTON_PIN_BUTTON1_IOMUX                            (IOMUX_PINCM25)
/* Defines for PIN_BUTTON2: GPIOB.9 with pinCMx 26 on package pin 61 */
#define GPIO_BUTTON_PIN_BUTTON2_IIDX                         (DL_GPIO_IIDX_DIO9)
#define GPIO_BUTTON_PIN_BUTTON2_PIN                              (DL_GPIO_PIN_9)
#define GPIO_BUTTON_PIN_BUTTON2_IOMUX                            (IOMUX_PINCM26)
/* Defines for PIN_BUTTON3: GPIOB.14 with pinCMx 31 on package pin 2 */
#define GPIO_BUTTON_PIN_BUTTON3_IIDX                        (DL_GPIO_IIDX_DIO14)
#define GPIO_BUTTON_PIN_BUTTON3_PIN                             (DL_GPIO_PIN_14)
#define GPIO_BUTTON_PIN_BUTTON3_IOMUX                            (IOMUX_PINCM31)
/* Defines for PIN_BUTTON4: GPIOB.15 with pinCMx 32 on package pin 3 */
#define GPIO_BUTTON_PIN_BUTTON4_IIDX                        (DL_GPIO_IIDX_DIO15)
#define GPIO_BUTTON_PIN_BUTTON4_PIN                             (DL_GPIO_PIN_15)
#define GPIO_BUTTON_PIN_BUTTON4_IOMUX                            (IOMUX_PINCM32)
/* Defines for PIN_3: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_xj_PIN_3_PORT                                               (GPIOA)
#define GPIO_xj_PIN_3_PIN                                       (DL_GPIO_PIN_22)
#define GPIO_xj_PIN_3_IOMUX                                      (IOMUX_PINCM47)
/* Defines for PIN_4: GPIOA.23 with pinCMx 53 on package pin 24 */
#define GPIO_xj_PIN_4_PORT                                               (GPIOA)
#define GPIO_xj_PIN_4_PIN                                       (DL_GPIO_PIN_23)
#define GPIO_xj_PIN_4_IOMUX                                      (IOMUX_PINCM53)
/* Defines for PIN_5: GPIOA.24 with pinCMx 54 on package pin 25 */
#define GPIO_xj_PIN_5_PORT                                               (GPIOA)
#define GPIO_xj_PIN_5_PIN                                       (DL_GPIO_PIN_24)
#define GPIO_xj_PIN_5_IOMUX                                      (IOMUX_PINCM54)
/* Defines for PIN_6: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GPIO_xj_PIN_6_PORT                                               (GPIOA)
#define GPIO_xj_PIN_6_PIN                                       (DL_GPIO_PIN_25)
#define GPIO_xj_PIN_6_IOMUX                                      (IOMUX_PINCM55)
/* Defines for PIN_7: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_xj_PIN_7_PORT                                               (GPIOA)
#define GPIO_xj_PIN_7_PIN                                       (DL_GPIO_PIN_31)
#define GPIO_xj_PIN_7_IOMUX                                       (IOMUX_PINCM6)
/* Defines for PIN_9: GPIOB.3 with pinCMx 16 on package pin 51 */
#define GPIO_xj_PIN_9_PORT                                               (GPIOB)
#define GPIO_xj_PIN_9_PIN                                        (DL_GPIO_PIN_3)
#define GPIO_xj_PIN_9_IOMUX                                      (IOMUX_PINCM16)
/* Defines for PIN_10: GPIOB.7 with pinCMx 24 on package pin 59 */
#define GPIO_xj_PIN_10_PORT                                              (GPIOB)
#define GPIO_xj_PIN_10_PIN                                       (DL_GPIO_PIN_7)
#define GPIO_xj_PIN_10_IOMUX                                     (IOMUX_PINCM24)
/* Defines for PIN_11: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_xj_PIN_11_PORT                                              (GPIOB)
#define GPIO_xj_PIN_11_PIN                                      (DL_GPIO_PIN_18)
#define GPIO_xj_PIN_11_IOMUX                                     (IOMUX_PINCM44)
/* Defines for PIN_12: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_xj_PIN_12_PORT                                              (GPIOB)
#define GPIO_xj_PIN_12_PIN                                      (DL_GPIO_PIN_19)
#define GPIO_xj_PIN_12_IOMUX                                     (IOMUX_PINCM45)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_0_init(void);
void SYSCFG_DL_TIMER_0_init(void);
void SYSCFG_DL_UART_0_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
